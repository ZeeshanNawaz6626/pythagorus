

<?php if(isset($_SESSION['user'])){ ?>
     <!-- end of mt-11 -->
<?php } ?>    

</div>

</body>

</html>
