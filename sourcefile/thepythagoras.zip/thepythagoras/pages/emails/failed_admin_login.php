5 Failed attempts:
<?php echo print_r($_SESSION['failed_admin_logins'], true); ?>