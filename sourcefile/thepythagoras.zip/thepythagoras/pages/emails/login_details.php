Hello,

Your password for <?php echo $gc['path']['web_root']; ?> has been reset

Your new login details are:

Username: <?php echo $user['email']; ?>

Password: <?php echo $new_pass; ?>

You can change your password on the settings page here: <?php echo $gc['profile']['dir']; ?>/mysettings

Regards,
<?php echo $gc['site_name']; ?> Team