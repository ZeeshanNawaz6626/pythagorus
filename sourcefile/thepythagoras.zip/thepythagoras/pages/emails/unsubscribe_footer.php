<br>
<br>
<br>
<br>
<br>
<br>
<br>This is not spam.
<br>This is an automated message that you received because you have an account with us, and something related to it happened. 
To stop these notifications you can <a href="<?php echo create_unsubscribe_link($existing_user['id'],'notifs'); ?>">unsubscribe</a>. 
Or, you can acces your <a href="<?php echo $gc['path']['web_root']; ?>/mysettings">settings page</a> and fine tune what notifications you wish to receive.