Hello,

You have requested to reset your password for <?php echo $gc['path']['web_root']; ?>. 

Follow this link to confirm the reset: <?php echo $gc['path']['web_root']; ?>/reset_pass?key=<?php echo $key; ?>

Regards, <?php echo $gc['site_name']; ?> Team