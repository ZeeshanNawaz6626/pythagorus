

Welcome to our website!
You created an account automatically by logging in with Google at <?php echo $gc['path']['web_root']; ?>. 

You can continue to login with Google next time, or you can user your account credentials that you can create by using the password reset link here: 

<?php echo $gc['path']['web_root']; ?>/reset_pass


Once activated, you will be able to login by all login methods that share the same email. 

Regards,
<?php echo $gc['site_name']; ?> Team


