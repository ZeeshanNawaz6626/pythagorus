<?php
// its set in config now
//$API_KEY = "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";