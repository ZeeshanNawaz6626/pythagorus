<?php require_once('inc.json_header.php'); ?>{
	"API_MODEL_options_available": {
	    "gpt-3.5-turbo": "Most capable GPT-3.5 model and optimized for chat at 1/10th the cost of text-davinci-003. While faster and cheaper than Davinci, this alternative may not provide the same quality responses. (4,096 tokens)",
	    "gpt-3.5-turbo-16k": "Same capabilities as the standard gpt-3.5-turbo model but with 4 times the context. (16,384 tokens)",
	    "gpt-4": "More capable than any GPT-3.5 model, able to do more complex tasks (8,192 tokens)",
	    "gpt-4-32k": "Same capabilities as the base gpt-4 mode but with 4x the context length. Will be updated with our latest model iteration (32,768 tokens).",
	    "text-davinci-003": "Can do any language task with better quality, longer output, and consistent instructions."
	},   
	"use_text_stream": true,
	"display_contacts_user_list": true,
	"display_avatar_in_chat": true,
	"display_copy_text_button_in_chat": true,
	"display_audio_button_answers": true,
	"display_microphone_in_chat": true,
	"microphone_speak_lang": "en-US",
	"filter_badwords": true,
	"chat_history": true,
	"chat_font_size": "17px",
	"shuffle_character": false,
	"dalle_img_size": "256x256",
	"dalle_generated_img_count": 4,
	"dalle_img_size_available": "256x256 OR 512x512 OR 1024x1024"	
}