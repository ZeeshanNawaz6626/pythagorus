<?php


//this runs inside ai_assistant_check_run.php ajax call, just before the last json output
//any customized scripts or output modifiers can be added here
//---------------------------------------------





?>